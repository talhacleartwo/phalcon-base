<div class="kt-subheader" style="padding: 0 25px;">
	<div class="kt-subheader__main">
		<div class="subheader" style="display: flex;">
			<h3 style="line-height: 20px;" class="kt-subheader__title"><?php echo $pagetitle; ?></h3> 
			<div class="kt-subheader__separator kt-subheader__separator--v"></div> 
			<div class="kt-subheader__desc"><?php echo $pagedetails; ?></div>
		</div>
	</div>
</div>
<!-- begin:: Header Topbar -->
<div class="kt-header__topbar">
    <!--[html-partial:include:{"file":"partials\/_topbar-my-cart.html"}]/-->
    <!--begin: User Bar -->
	<div class="kt-header__topbar-item kt-header__topbar-item--user">
		<div class="kt-header__topbar-wrapper" data-toggle="dropdown" data-offset="0px,0px">
			<div class="kt-header__topbar-user">
				<?php
					$name = $this->auth->getName();
					$i1 = explode(" ",$name)[0];
					$i2 = explode(" ",$name)[1];
					$i1 = substr($i1,0,1);
					$i2 = substr($i2,0,1);
				?>
				<span class="kt-header__topbar-welcome kt-hidden-mobile">Hi,</span> <span class="kt-header__topbar-username kt-hidden-mobile"><?php echo $name; ?></span> 
				<!--<img class="kt-hidden" alt="Pic" src="/theme/assets/media/users/300_25.jpg" />-->
				<!--use below badge element instead the user avatar to display username's first letter(remove kt-hidden class to display it) -->
				<span class="kt-badge kt-badge--username kt-badge--unified-brand kt-badge--lg kt-badge--rounded kt-badge--bold"><?php echo $i1 . $i2;?></span> 
			</div>
		</div>
		<div class="dropdown-menu dropdown-menu-fit dropdown-menu-right dropdown-menu-anim dropdown-menu-top-unround dropdown-menu-xl">
			<?php $this->partial("partials/header/user-dropdown"); ?>
		</div>
	</div>
	<!--end: User Bar -->
</div>
<!-- end:: Header Topbar -->