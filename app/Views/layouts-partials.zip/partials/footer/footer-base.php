<!-- begin:: Footer -->
<div class="kt-footer kt-grid__item kt-grid kt-grid--desktop kt-grid--ver-desktop" id="kt_footer">
    <div class="kt-container kt-container--fluid ">
        <div class="kt-footer__copyright">DEA Inventories &copy; <?php echo date('Y'); ?> - Powered By <a style="margin-left:5px;" href="https://cleartwo.co.uk" target="_blank" class="kt-link">Cleartwo</a></div>
        <div class="kt-footer__menu"><a href="mailto:support@cleartwo.co.uk" class="kt-footer__menu-link kt-link">Contact</a></div>
    </div>
</div>
<!-- end:: Footer -->