<div class="edittask_overlay hidden"></div>
<div id="task_edit_window" class="hidden">
	
	<div class="kt-portlet light portlet-fit" style="margin: 0;">
		<div class="kt-portlet__head">
			<div class="kt-portlet__head-label">
				<h3 class="kt-portlet__head-title">
					Task Editor
					<small class="open_for"></small>
					<!--<small class="customer"></small>-->
				</h3>
			</div>
			<div class="kt-portlet__head-toolbar">
				<div class="kt-portlet__head-actions">
					<button class="btn btn-info add_timesheet" style="display:none;">
						Timesheet<i class="fa fa-plus" style="padding-left: 0.5rem;padding-right: 0;"></i>
					</button>
					<button class="btn btn-primary complete">Complete</button>
					<button class="btn btn-warning open_notes">
						Notes<i class="fa fa-chevron-right" style="padding-left: 0.5rem;padding-right: 0;"></i>
					</button>
				</div>
			</div>
		</div>
		<div class="kt-portlet__body">
			<form id="et_form" action="" method="POST">
				<input type="hidden" class="previous" name="prev_Subject" value=""/>
				<input type="hidden" class="previous s" name="prev_StatusCode" value=""/>
				<input type="hidden" class="previous" name="prev_StartDateTime" value=""/>
				<input type="hidden" class="previous" name="prev_DueDateTime" value=""/>
				<input type="hidden" class="previous" name="prev_Duration" value=""/>
				<input type="hidden" class="previous" name="prev_Description" value=""/>
				<input type="hidden" class="previous s" name="prev_OwnerId" value=""/>
				<input type="hidden" name="usertype" value=""/>
				<div class="fields">
					<div class="row">
						<div class="col-md-3">
							<div class="form-group">
								<label>Owner:</label>
								<select name="OwnerId" class="form-control" style="width:100%;">
									<!--<optgroup label="Users">
										<?php
											/*sort($UsersAndTeams->Users);
											foreach($UsersAndTeams->Users as $user)
											{
												echo '<option data-usertype="systemuser" value="'.$user->Id.'">'.$user->Name.'</option>';
											}*/
										?>
									</optgroup>
									<optgroup label="Teams">
										<?php
											/*sort($UsersAndTeams->Teams);
											foreach($UsersAndTeams->Teams as $team)
											{
												echo '<option data-usertype="team" value="'.$team->Id.'">'.$team->Name.'</option>';
											}*/
										?>
									</optgroup>-->
								</select>
							</div>
							<div class="form-group">
								<label>Status:</label>
								<select name="StatusCode" class="form-control">
									<option value="2">Not Started</option>
									<option value="3">In Progress</option>
									<option value="4">QA</option>
									<option value="7">Deferred</option>
								</select>
							</div>
							<div class="form-group quickEditFields">
								<label>Start Date:</label>
								<input type="text" name="StartDateTime" class="form-control et_datetimefield"/>
							</div>
							<div class="form-group quickEditFields">
								<label>Duration: </label>
								<div class="duration_picker">
									<input type="hidden" name="prev_Duration"/>
									<input type="hidden" name="Duration"/>
									<div class="visible">
										<input class="form-control duration_value" type="number" value="30"/
										><select class="form-control duration_unit">
											<option value="mins">Minutes</option>
											<option value="hours">Hours</option>
											<option value="days">Days</option>
										</select>
									</div>
								</div>
							</div>
							<div class="form-group quickEditFields">
								<label>Due Date:</label>
								<input type="text" name="DueDateTime" class="form-control et_datetimefield" disabled/>
							</div>
						</div>
						<div class="col-md-9">
							<div class="form-group">
								<label>Subject:</label>
								<input type="text" name="Subject" class="form-control"/>
							</div>
							<div class="row">
								<div class="col-md-6">
									<div class="form-group">
										<label>Account:</label>
										<input type="text" name="CustomerId" class="form-control" disabled/>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-group">
										<label>Opportunity:</label>
										<input type="text" name="OpportunityId" class="form-control" disabled/>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label>Description:</label>
								<textarea id="EditTaskDescription" name="Description" class="form-control" style="min-height: 150px;"></textarea>
							</div>
						</div>
					</div>
					<div class="actions">
						<div class="left">
							<button class="btn btn-danger close_window">Cancel</button>
						</div
						><div class="right" style="text-align:right;">
							<button class="btn btn-success update">Update</button>
						</div>
					</div>
				</div>
			</form>
			<div class="notes_window">
				<div class="kt-portlet light portlet-fit" style="margin: 0;z-index: 99;min-height: 580px;">
					<div class="kt-portlet__head">
						<div class="kt-portlet__head-label">
							<h3 class="kt-portlet__head-title">
								Task Notes
							</h3>
						</div>
						<div class="kt-portlet__head-toolbar">
							<div class="kt-portlet__head-actions">
								<button class="btn btn-danger btn-icon btn-sm close_task_notes">
									<i class="fa fa-times"></i>
								</button>
							</div>
						</div>
					</div>
					<div class="kt-portlet__body">
						<?php echo $this->CRMAPI->ajaxLoader(); ?>
						<div class="content"></div>
						<div class="create_note">
							<form method="POST" class="create_note_form">
								<input type="hidden" name="objectId" value=""/>
								<input type="hidden" name="objectType" value="task"/>
								<input type="hidden" name="subject" value=""/>
								<textarea style="margin-bottom:5px;" class="form-control" name="note_text" placeholder="Enter your note here.."></textarea>
								<input style="margin-bottom: 5px;" type="file" name="attachment"/>
								<button style="width: 100%;" type="submit" class="btn btn-success">Create Note</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div id="timesheet_window" class="hidden">
	<input type="hidden" name="Subject" value=""/>
	<input type="hidden" name="StartDate" value=""/>
	<input type="hidden" name="Description" value=""/>
	<input type="hidden" name="OwnerId" value=""/>
	<input type="hidden" name="CustomerId" value=""/>
	<input type="hidden" name="OpportunityId" value=""/>
	<input type="hidden" name="RegardingObjectType" value=""/>
	<div class="kt-portlet">
		<div class="kt-portlet__head">
			<div class="kt-portlet__head-label">
				<h3 class="kt-portlet__head-title">
					Create Timesheet
				</h3>
			</div>
			<div class="kt-portlet__head-toolbar">
				<div class="kt-portlet__head-actions">
					<button class="btn btn-primary create_timesheet">Create</button>
				</div>
			</div>
		</div>
		<div class="kt-portlet__body">
			<div class="form-group">
				<label>Duration: </label>
				<div class="duration_picker">
					<input type="hidden" name="Duration"/>
					<div class="visible">
						<input class="form-control duration_value" type="number" value="30"/
						><select class="form-control duration_unit">
							<option value="mins">Minutes</option>
							<option value="hours">Hours</option>
							<option value="days">Days</option>
						</select>
					</div>
				</div>
			</div>
			<div class="form-group comments">
				<label>Comments</label>
				<textarea name="Comments" class="form-control" placeholder="Describe the work carried out.."></textarea>
			</div>
		</div>
	</div>
</div>
<div id="timesheetPrompt" class="hidden">
	<h5 class="title">Would you like to create a timesheet for this task?</h5>
	<div class="buttons">
		<button class="btn btn-sm btn-danger cancel">Cancel</button>
		<button class="btn btn-sm btn-success opt_2">Complete & Timesheet</button>
		<button class="btn btn-sm btn-primary opt_1">Complete Only</button>
	</div>
</div>