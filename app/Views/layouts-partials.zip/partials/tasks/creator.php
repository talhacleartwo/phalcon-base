<div class="createtask_overlay hidden"></div>
<div id="create_task_modal" class="hidden">
	<div class="kt-portlet light portlet-fit" style="margin: 0;">
		<div class="kt-portlet__head">
			<div class="kt-portlet__head-label">
				<h3 class="kt-portlet__head-title">
					Create Task
					<small class="open_for"></small>
				</h3>
			</div>
		</div>
		<div class="kt-portlet__body">
			<form id="ct_form" method="POST">
				<input type="hidden" name="usertype" value=""/>
				<div class="row">
					<div class="col-md-3">
						<div class="form-group">
							<label>Owner*</label>
							<input type="hidden" name="OwnerType" value=""/>
							<select name="OwnerId" class="form-control select2" style="width:100%;">
								
							</select>
						</div>
						<div class="form-group">
							<label>Status</label>
							<select name="StatusCode" class="form-control" disabled>
								<option value="2" selected>Not Started</option>
								<option value="3">In Progress</option>
								<option value="4">QA</option>
								<option value="7">Deferred</option>
							</select>
						</div>
						<div class="form-group">
							<label>Start Date*</label>
							<input type="text" name="StartDateTime" class="form-control ct_datetimefield" autocomplete="off"/>
						</div>
						<div class="form-group">
							<label>Duration* </label>
							<div class="duration_picker">
								<input type="hidden" name="prev_Duration"/>
								<input type="hidden" name="Duration" value="30"/>
								<div class="visible">
									<input class="form-control duration_value" type="number" min="15" step="0.25" value="30"/
									><select class="form-control duration_unit">
										<option value="mins">Minutes</option>
										<option value="hours">Hours</option>
										<option value="days">Days</option>
									</select>
								</div>
							</div>
						</div>
						<div class="form-group">
							<label>Due Date*</label>
							<input type="text" name="DueDateTime" class="form-control ct_datetimefield" autocomplete="off"/>
						</div>
					</div>
					<div class="col-md-9">
						<div class="form-group">
							<label>Subject*</label>
							<input type="text" name="Subject" class="form-control" autocomplete="off"/>
						</div>
						<div class="row generic_fields">
							<div class="col-md-6">
								<div class="form-group">
									<label>Account* </label>
									<select name="CustomerId" class="form-control select2" style="width:100%;">
										<option></option>
									</select>
								</div>
							</div>
							<div class="col-md-6">
								<div class="form-group">
									<label>Opportunity*</label>
									<select name="OpportunityId" class="form-control select2" style="width:100%;">
										<option></option>
									</select>
								</div>
							</div>
						</div>
						<div class="form-group">
							<label>Description*</label>
							<textarea id="CreateTaskDescription" name="Description" class="form-control" style="min-height: 150px;"></textarea>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						
					</div>
					<div class="col-md-6">
						
					</div>
				</div>
				<div class="row">
					<div class="col-md-4">
						
					</div>
					<div class="col-md-4">
						
					</div>
					<div class="col-md-4">
						
					</div>
				</div>
				
				<div class="row">
					<div class="col-md-12">
						
					</div>
				</div>
				<div class="actions">
					<div class="left">
						<button class="btn btn-danger close_window">Cancel</button>
					</div
					><div class="right" style="text-align:right;">
						<button id="ct_submit" class="btn btn-success update">Create</button>
					</div>
				</div>
			</form>
		</div>
		<!--<div class="modal-footer">
			<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
			<button type="button" id="ct_submit" class="btn btn-primary">Create Task</button>
		</div>-->
	</div>
</div>